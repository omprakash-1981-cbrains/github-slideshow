class CategoriesModel{
  String categorieName;
  String imgUrl;

}