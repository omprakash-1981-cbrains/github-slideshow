class User{
  String userId;

  User({this.userId});
}