import 'package:flutter/material.dart';

const hintColor = Color(0xff7689e6);
const textFieldColor = Color(0xff173cea);
const secondaryTextColor = Color(0xff4f4545);


const borderEnabledColor = Color(0xffd5cccc  );
const borderFocusedColor = Color(0xff2b3ca0);
//app color
final backgroundColor = Colors.white;
const appBarColor = Color(0xff7689e6);

//button
const buttonMain = Color(0xff7689e6);
const buttonSecondary = Color(0xff43c0d9);




